import pool from "../db.js";

/**
 * GET all seats
 */
export const getAllSeats = async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT * FROM seats ORDER BY seat_no"
    );
    res.json(result.rows);
  } catch (err) {
    console.error("❌ getAllSeats error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};

/**
 * BOOK seat (Concurrency-safe)
 */
export const bookSeat = async (req, res) => {
  const { seat_no, user_id } = req.body;

  if (!seat_no || !user_id) {
    return res.status(400).json({
      error: "seat_no and user_id are required"
    });
  }

  const seatNo = seat_no.trim().toUpperCase();
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    const seat = await client.query(
      "SELECT status FROM seats WHERE seat_no = $1 FOR UPDATE",
      [seatNo]
    );

    if (seat.rows.length === 0) {
      throw new Error("Seat not found");
    }

    if (seat.rows[0].status !== "AVAILABLE") {
      throw new Error("Seat already booked");
    }

    await client.query(
      `UPDATE seats
       SET status = 'BOOKED',
           user_id = $1,
           booked_at = NOW()
       WHERE seat_no = $2`,
      [user_id, seatNo]
    );

    await client.query("COMMIT");
    res.json({ message: "Seat booked successfully" });

  } catch (err) {
    await client.query("ROLLBACK");
    res.status(400).json({ error: err.message });
  } finally {
    client.release();
  }
};

/**
 * CANCEL seat booking
 */
export const cancelSeat = async (req, res) => {
  const { seat_no } = req.body;

  if (!seat_no) {
    return res.status(400).json({
      error: "seat_no is required"
    });
  }

  const seatNo = seat_no.trim().toUpperCase();

  try {
    const seat = await pool.query(
      "SELECT status FROM seats WHERE seat_no = $1",
      [seatNo]
    );

    if (seat.rows.length === 0) {
      return res.status(404).json({
        error: "Seat not found"
      });
    }

    if (seat.rows[0].status === "AVAILABLE") {
      return res.status(400).json({
        error: "Seat is already available"
      });
    }

    await pool.query(
      `UPDATE seats
       SET status = 'AVAILABLE',
           user_id = NULL,
           booked_at = NULL
       WHERE seat_no = $1`,
      [seatNo]
    );

    res.json({
      message: "Seat booking cancelled successfully"
    });

  } catch (err) {
    res.status(500).json({ error: "Internal server error" });
  }
};
