import express from "express";
import {
  getAllSeats,
  bookSeat,
  cancelSeat
} from "../controllers/seat.controller.js";

const router = express.Router();

router.get("/seats", getAllSeats);
router.post("/book", bookSeat);
router.post("/cancel", cancelSeat);

export default router;
