const API_URL = "http://localhost:3000/api";
const seatMap = document.getElementById("seat-map");
const toast = document.getElementById("toast");

function showToast(msg, type) {
  toast.textContent = msg;
  toast.className = `toast ${type}`;
  toast.style.display = "block";
  setTimeout(() => toast.style.display = "none", 2500);
}

async function loadSeats() {
  seatMap.innerHTML = "";

  const res = await fetch(`${API_URL}/seats`);
  const seats = await res.json();

  // Group seats by row
  const seatByRow = {};
  seats.forEach(seat => {
    const row = seat.seat_no.slice(1);
    const col = seat.seat_no[0];
    seatByRow[row] = seatByRow[row] || {};
    seatByRow[row][col] = seat;
  });

  Object.keys(seatByRow).sort((a,b)=>a-b).forEach(row => {
    // Row number
    const rowLabel = document.createElement("div");
    rowLabel.textContent = row;
    rowLabel.className = "row-label";
    seatMap.appendChild(rowLabel);

    // A B C
    ["A","B","C"].forEach(col =>
      createSeat(row, col, seatByRow[row][col])
    );

    // Aisle
    seatMap.appendChild(document.createElement("div"));

    // D E F
    ["D","E","F"].forEach(col =>
      createSeat(row, col, seatByRow[row][col])
    );
  });
}

function createSeat(row, col, seatData) {
  const seatDiv = document.createElement("div");
  seatDiv.className = "seat";
  seatDiv.textContent = col;

  if (!seatData || seatData.status !== "AVAILABLE") {
    seatDiv.classList.add("booked");

    seatDiv.onclick = () => {
      const confirmCancel = confirm(
        `Cancel booking for seat ${seatData.seat_no}?`
      );
      if (confirmCancel) {
        cancelSeat(seatData.seat_no);
      }
    };

  } else {
    seatDiv.classList.add("available");
    seatDiv.onclick = () => bookSeat(seatData.seat_no);
  }

  seatMap.appendChild(seatDiv);
}

async function bookSeat(seatNo) {
  const userId = prompt("Enter User ID");
  if (!userId) return;

  const res = await fetch(`${API_URL}/book`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      seat_no: seatNo,
      user_id: userId
    })
  });

  const data = await res.json();

  if (data.message) {
    showToast(data.message, "success");
  } else {
    showToast(data.error, "error");
  }

  loadSeats();
}

async function cancelSeat(seatNo) {
  const res = await fetch(`${API_URL}/cancel`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ seat_no: seatNo })
  });

  const data = await res.json();

  if (data.message) {
    showToast(data.message, "success");
  } else {
    showToast(data.error, "error");
  }

  loadSeats();
}

// Initial load
loadSeats();
